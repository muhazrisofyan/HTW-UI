@extends('layouts.master')

@section('content')
  <div class="w3-row w3-container">
    <p>Pilih tahun:</p>
    <div class="w3-col s4 w3-center" style="padding-left:20px;padding-right:20px">
      <a href="gallery/category" style="text-decoration:none">
        <div class="w3-white w3-round-large w3-card-4">
          <h2>2018</h2>
        </div>
      </a>
    </div>
    <div class="w3-col s4 w3-center" style="padding-left:20px;padding-right:20px">
      <a href="#" style="text-decoration:none">
        <div class="w3-white w3-round-large w3-card-4">
          <h2>2017</h2>
        </div>
      </a>
    </div>
    <div class="w3-col s4 w3-center" style="padding-left:20px;padding-right:20px">
      <a href="#" style="text-decoration:none">
        <div class="w3-white w3-round-large w3-card-4">
          <h2>2016</h2>
        </div>
      </a>
    </div>
    <div class="w3-col s4 w3-center" style="padding-left:20px;padding-right:20px">
      <a href="#" style="text-decoration:none">
        <div class="w3-white w3-round-large w3-card-4">
          <h2>2015--</h2>
        </div>
      </a>
    </div>
  </div>
@endsection
