@extends('layouts.master')

@section('content')
<div class="w3-content">
  <h1 class="w3-center">Baby Shark team</h1>
  <img src="#" style="width:100%;margin-top:20px" alt ="Baby Shark Team photo">

  <h2>Ketua Tim</h2>
  <li>Farghani Fariz</li>
  <h2>Anggota Tim</h2>

<li>Siti Agrisylva</li>
<li>Intan Chairina</li>
<li>Yuliani Caraka</li>
<li>Yaser</li>
<li>Sayyid</li>
<li>Fitrah I</li>
<li>Azmi S</li>
<li>Bukhari R</li>

</div>
@endsection
