@extends('layouts.master')

@section('content')
<div class="w3-content">
  <h1 class="w3-center">Rocky Patrick Team</h1>
  <img src="/img/nasional/rocky.jpg" style="width:100%;margin-top:20px">

  <h2>Ketua Tim</h2>
  <li>Andaru Wiratama</li>
  <h2>Anggota Tim</h2>
  <li>A. A. Ananta</li>
  <li>Astri Amalia</li>
  <li>Fadhil Zuhdi</li>
  <li>M. A. Jofansya</li>
  <li>Azis</li>
  <li>Rudi</li>
  <li>Bimo A.</li>
  <li>Aang</li>
  <li>Rio</li>

</div>
@endsection
