@extends('layouts.master')

@section('content')
<div class="w3-content">
  <h1 class="w3-center">Alpha Eagle Team</h1>
  <img src="/img/nasional/alpha.jpg" style="width:100%;margin-top:20px">

  <h2>Ketua Tim</h2>

  <h2>Anggota Tim</h2>
</div>
@endsection
