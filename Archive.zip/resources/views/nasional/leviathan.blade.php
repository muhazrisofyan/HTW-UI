@extends('layouts.master')

@section('content')
<div class="w3-content">
  <h1 class="w3-center">Leviathan team</h1>
  <img src="" style="width:100%;margin-top:20px" alt="Leviathan team photo">

  <h2>Ketua Tim</h2>
  <li>Fadhil N.</li>
  <h2>Anggota Tim</h2>
  <li>Satyo Yuwono</li>
  <li>Dzaky Ridho</li>
  <li>Fauzan Zuhdi</li>
  <li>Dwi Refarianto</li>
  <li>Fadhil Dwinanda</li>
  <li>Ilham Santosa</li>
  <li>Bagus F.</li>
  <li>Faril Ichfari</li>
  <li>Hadyan Basyiri</li>
</div>
@endsection
