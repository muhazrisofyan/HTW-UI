<?php $__env->startSection('content'); ?>
<div class="w3-content">
  <h1 class="w3-center">Arafuru Team</h1>
  <img src="/img/nasional/arafuru.jpg" style="width:100%;margin-top:20px">

  <h2>Ketua Tim</h2>
  <li>Rayhan</li>
  <h2>Anggota Tim</h2>
  <li>Satria Bagas</li>
  <li>M. Zyan Beckham</li>
  <li>Januri Akbar</li>
  <li>M. Rais Habibi</li>
  <li>M. Zuhdi Ali</li>
  <li>Zahwa C.</li>
  <li>Zahra S.</li>
  <li>Yohanes Kevano</li>
  <li>Aly Abdussalam</li>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>