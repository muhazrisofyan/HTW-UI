<?php $__env->startSection('content'); ?>
<div class="w3-content">
  <h1 class="w3-center">Alpha Eagle Team</h1>
  <img src="/img/nasional/kria.jpg" style="width:100%;margin-top:20px">

  <h2>Ketua Tim</h2>
  <li>Dandi</li>
  <h2>Anggota Tim</h2>
  <li>Bintang F.</li>
  <li>Michael Ahli</li>
  <li>Muthia Aurora</li>
  <li>Nomensen Pararathon</li>
  <li>M. Athallah</li>
  <li>Djordan Ranadi</li>
  <li>Edo Wanda</li>
  <li>Ferdinan Asyhadinata</li>
  <li>Deju Kevin</li>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>