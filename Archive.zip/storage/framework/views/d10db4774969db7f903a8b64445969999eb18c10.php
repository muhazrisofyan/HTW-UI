<?php $__env->startSection('content'); ?>
<div class="w3-content">
  <h1 class="w3-center">V-Max Team</h1>
  <img src="" style="width:100%;margin-top:20px" alt = "V-Max team photo">

  <h2>Ketua Tim</h2>
  <li>Stefanus</li>
  <h2>Anggota Tim</h2>
  <li>Farhan Syahputra</li>
  <li>Cornelius</li>
  <li>Fadhil Azharrisman</li>
  <li>Antoni</li>
  <li>Zaqi Baharudin</li>
  <li>Apri melianes</li>
  <li>Rizal</li>
  <li>Ilham Hutama</li>
  <li>Goldan Tambayong</li>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>