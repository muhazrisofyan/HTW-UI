<?php $__env->startSection('content'); ?>
  <div class="w3-content">
    <div class="w3-content w3-center w3-padding-24" style="padding-left:20px;padding-right:20px;width:400px">
      <a href="/gallery/2018/kegiatan" style="text-decoration:none">
        <div class="w3-white w3-round-large w3-card-4">
          <h2>Kegiatan</h2>
        </div>
      </a>
    </div>
    <div class="w3-content w3-center w3-padding-24" style="padding-left:20px;padding-right:20px;width:400px">
      <a href="/gallery/2018/lomba" style="text-decoration:none">
        <div class="w3-white w3-round-large w3-card-4">
          <h2>Lomba</h2>
        </div>
      </a>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>