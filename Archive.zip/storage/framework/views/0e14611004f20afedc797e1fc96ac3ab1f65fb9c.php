<?php $__env->startSection('content'); ?>
<div class="w3-content">
  <h1 class="w3-center">Poseidon Team</h1>
  <img src="/img/nasional/pos1.jpg" style="width:100%;margin-top:20px">

  <h2>Ketua Tim</h2>
  <li>Gigih Putro P.</li>
  <h2>Anggota Tim</h2>
  <li>Martin Nicolas</li>
  <li>Hamnah Ayuningtyas</li>
  <li>Nadhilah</li>
  <li>Verdi Benediktus</li>
  <li>Darfian Ruswifaqa</li>
  <li>Edwin Bastian</li>
  <li>Whisnu Febriansyah</li>
  <h2>Pengalaman Lomba</h2>
  <li>NASDARC ITS 2018</li>
  <li>Juara 3 Mechanical and Marine Engineering National Exposition UI Eco RC Boat Racing 2017</li>
  <li>Juara 3 Eco Solar Boat Marine Icon ITS 2017</li>

  <img src="/img/nasional/pos2.jpg" style="width:100%;margin-top:20px">
  <img src="/img/nasional/pos3.jpg" style="width:100%;margin-top:20px">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>